import os,json
os.environ['CUDA_VISIBLE_DEVICES'] = ''
from django.shortcuts import render, redirect
from django.http import HttpResponse,JsonResponse
import tensorflow as tf
import numpy as np 
import cv2 
import tempfile
from django.conf import settings
from django.core.files.storage import default_storage
from object_detection.utils import label_map_util
from object_detection.utils import visualization_utils as viz_utils
from object_detection.builders import model_builder
from object_detection.utils import config_util
import collections



def generate_objects(price, names):
  objects = []
  class_counts = collections.Counter(names)
  for name, count in class_counts.items():
    object = {'name': name, 'quatity': count, 'price': price[name]}
    objects.append(object)
  return objects
price ={'Alu_Bhorta': 230, 'Begun_Vaji': 262, 'Biriyani': 111, 'Boiled_Eggs': 165, 'Borhani': 134, 'Burger': 191, 
        'Cake': 327, 'Chicken_Curry': 346, 'Dim_vaji': 336, 'Falooda': 316, 'Fish_curry': 157, 'Kacchi': 344,
          'Khichuri': 303, 'Meat_Curry': 463, 'Paratha': 362, 'Rice': 327, 'Salad': 153, 'Sandwich': 173, 'Shak_vaji': 345, 
          'Vegetable_curry': 263, 'Cold_Drinks': 271, 'Shingara': 248}


# Load pipeline config and build a detection model
configs = config_util.get_configs_from_pipeline_file('billing\my_ssd_mobnet\pipeline.config')
detection_model = model_builder.build(model_config=configs['model'], is_training=False)

# Restore checkpoint
ckpt = tf.compat.v2.train.Checkpoint(model=detection_model)
ckpt.restore(os.path.join('billing\my_ssd_mobnet', 'ckpt-7')).expect_partial()

@tf.function
def detect_fn(image):
    image, shapes = detection_model.preprocess(image)
    prediction_dict = detection_model.predict(image, shapes)
    detections = detection_model.postprocess(prediction_dict, shapes)
    return detections

category_index = label_map_util.create_category_index_from_labelmap('billing\my_ssd_mobnet\label_map.pbtxt',use_display_name=True)
def home2(request):
    if request.method == 'POST':
        
        image = request.FILES['image']
        pathh=''
        # with tempfile.NamedTemporaryFile(suffix='.jpg') as f:
        #     for chunk in image.chunks():
        #         f.write(chunk)
        #     f.seek(0) 
        #     pathh=f.name    
        if image:
            # Generate a unique filename for the image
            filename = default_storage.get_available_name(image.name)
            # Save the image to the media directory
            path = default_storage.save(filename, image)   
        path=r'C:\Users\Acer\Desktop\Web\capstone\media'+'\\'+ str(path)
        IMAGE_PATH = path
        img = cv2.imread(IMAGE_PATH)
        image_np = np.array(img)

        input_tensor = tf.convert_to_tensor(np.expand_dims(image_np, 0), dtype=tf.float32)
        detections = detect_fn(input_tensor)

        num_detections = int(detections.pop('num_detections'))
        detections = {key: value[0, :num_detections].numpy()
                    for key, value in detections.items()}
        # detection_classes should be ints.
        detections['detection_classes'] = detections['detection_classes'].astype(np.int64)
        detections['num_detections'] = num_detections
        boxes=detections['detection_boxes']
        classes=detections['detection_classes']+1
        scores=detections['detection_scores']
        
        threshold = 0.3
        boxes = boxes[scores >= threshold]
        classes = classes[scores >= threshold]
        class_name = [category_index[x]['name'] for x in classes ]
        print(classes)
        image_np_with_detections = image_np.copy()
        object = generate_objects(price, class_name)

        return JsonResponse({'boxes':boxes.tolist(),'labels':classes.tolist(),'image':path,'category':category_index,'items':object})
    return render(request, 'bill.html')


